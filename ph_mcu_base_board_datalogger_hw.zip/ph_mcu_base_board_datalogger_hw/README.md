# ph_mcu_base_board_datalogger_hw

ph_mcu_base_board_datalogger_hw

![Hinh anh 1](./assets/ph_mcu_base_board_datalogger_hw_top.png)

![Hinh anh 1](./assets/ph_mcu_base_board_datalogger_hw_bot.png)