# ph_analyzer_tp_control_sample_react_hw
This is hardware sample and reactor controller for project analyzer Sum Photpho

# Description

## Features:
    * Power input 24VDC (isolation 24VDC - 5VDC 1W)
    * Control Multiport Valves and Syringe Pumps (RS485)
    * 12 Output isolation (9 output Relay, 3 output NPN)
    * 9 Input NPN isolation
    * 1 Sensor PT100
    * 1 PWM control thermal resistance (with Measure and control current)
    * Button select mode bootloader.
    * Communication 485 (status, control signal,...)
# Hardware
## Schematics

[Download](./ph_analyzer_tp_control_sample_react_hw.pdf)

- Test thử vào chế độ bootloader chỉ với 1 nút nhấn (reset and boot, k phải giữ boot sau đó bấm reset, đợi đến 4 chu kỳ máy thả boot)

![BOOT-IMG](./assets/boot-mode-schema.png)

## PCB Layout

![TOP-IMG](./assets/ph_analyzer_tp_control_sample_react_hw_top.png)

![BOT-IMG](./assets/ph_analyzer_tp_control_sample_react_hw_bot.png)

## 3D

![TOP-3D-IMG](./assets/ph_analyzer_tp_control_sample_react_hw_3d_top.png)

![BOT-3D-IMG](./assets/ph_analyzer_tp_control_sample_react_hw_3d_bot.png)

## Pinout

# Gerber

[Download](./gerber/gerber_ph_analyzer_tp_control_sample_react_hw.zip)

# BOMLIST

[Download](./assets/bom_ph_analyzer_tp_control_sample_react_hw.csv)

# License

![PHUONGHAI](./assets/license.png)