# stm32_st7920_lcd_hw
stm32_st7920_lcd_hw

![](./assets/top.png)

![](./assets/bot.png)